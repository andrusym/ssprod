import React, { useState } from 'react';

const TradeJournalEditor = ({ initialNote, onSave }) => {
  const [note, setNote] = useState(initialNote || "");

  const handleSave = () => {
    onSave(note);
  };

  return (
    <div className="journal-editor">
      <textarea value={note} onChange={e => setNote(e.target.value)} />
      <button onClick={handleSave}>Save Note</button>
    </div>
  );
};

export default TradeJournalEditor;