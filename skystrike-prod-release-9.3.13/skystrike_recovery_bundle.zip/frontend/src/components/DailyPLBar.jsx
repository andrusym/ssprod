import React from 'react';

const DailyPLBar = ({ pl }) => {
  return (
    <div className="daily-pl-bar">
      <h4>Daily P&L: ${pl}</h4>
    </div>
  );
};

export default DailyPLBar;