import React, { useEffect, useState } from "react";

const ThemeToggle = () => {
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    document.body.className = theme;
    const logo = document.getElementById("skystrike-logo");
    if (logo) {
      logo.src = theme === "dark"
        ? "/src/assets/skystrike-logo-light.png"
        : "/src/assets/skystrike-logo-dark.png";
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === "light" ? "dark" : "light"));
  };

  return <button onClick={toggleTheme}>Toggle Theme</button>;
};

export default ThemeToggle;